#!/bin/bash
#/etc/profile.d/spstool.sh

if [ -f /home/smile/spstool.sh ]; then
  bash /home/smile/spstool.sh sysinfo
fi
